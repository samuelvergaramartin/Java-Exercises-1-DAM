# Ejercicios dictados

1 - Haz un programa que lea desde teclado de 10 alumnos y las muestre en pantalla.
2 - Haz un programa que genere tres combinaciones de loteria de 6 numeros aleatorios y muestre los 3. Los numeros van del 1 al 49
3 - Haz un programa que inicialice en el codigo un array que va contener la edad de 10 alumnos. Le tenemos que pedir al usuario que introduzca un alumno y le cambie la edad. Posteriormente, mostramos el array.