/**
 * @author Samuel Vergara Martín
 */
public class ActividadRefuerzo2 {
    public static void main(String[] args) {
        int multiplo5 = 0;
        while(multiplo5 < 105) {
            System.out.println(multiplo5);
            multiplo5+=5;
        }
    }
}
