/**
 * @author Samuel Vergara Martín
 */
public class ActividadRefuerzo1 {
    public static void main(String[] args) {
        int x;
        
        for(x=0; x <= 100;x+=5) {
            System.out.println(x);
        }

        System.exit(0);
    }
}