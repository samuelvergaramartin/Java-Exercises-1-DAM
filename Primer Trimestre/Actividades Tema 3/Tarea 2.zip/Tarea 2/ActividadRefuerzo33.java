
/**
 * @author Samuel Vergara Martín
 */
import java.util.Scanner;

public class ActividadRefuerzo33 {
    public static void main(String[] args) {
        int num;
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduzca la altura de la U: ");
        num = sc.nextInt();

        sc.close();

        
    }
}
