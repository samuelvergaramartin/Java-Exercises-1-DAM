/**
 * @author Samuel Vergara Martín
 */
public class ActividadRefuerzo4 {
    public static void main(String[] args) {
        for(int i = 320; i >= 160; i = i -20) {
            System.out.println(i);
        }
    }
}
