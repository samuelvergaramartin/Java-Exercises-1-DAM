/**
 * @author Samuel Vergara Martín
 */
public class Actividad3P7 {
    public static void main(String[] args) {
        for(int i = 0; i < 100; i+=7) {
            System.out.println(i);
        }
    }
}
